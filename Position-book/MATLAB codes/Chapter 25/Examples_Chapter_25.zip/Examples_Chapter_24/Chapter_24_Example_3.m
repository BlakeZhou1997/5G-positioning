mpol x y z
a=[10, 13, 14;%anchor positions
   20, 5, 40;
   12, 15,  -10;
   0, 32, 5 ] ; 
d=[ 22.4388, 46.0740, 22.8327, 33.3214]; %measured distances to the anchors
J=0;
for i=1:4
   J=J+((x-a(i,1))^2+(y-a(i,2))^2-d(i)^2)^2;
end
Jx=diff(J,x);
Jy=diff(J,y);
VC=solve(Jx,Jy);
