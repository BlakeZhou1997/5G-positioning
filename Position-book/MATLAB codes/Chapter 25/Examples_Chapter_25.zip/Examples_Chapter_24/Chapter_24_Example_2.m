syms x y
a=[0 0; %anchor positions
   43 7;
   47 0];
d=[35 42 43]; %measured distances to the anchors
J=0;
for i=1:3
   J=J+((x-a(i,1))^2+(y-a(i,2))^2-d(i)^2)^2;
end
Jx=diff(J,x);
Jy=diff(J,y);
VC=solve(Jx,Jy);