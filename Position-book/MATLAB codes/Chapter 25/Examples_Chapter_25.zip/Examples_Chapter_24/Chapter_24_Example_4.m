%Using GloptiPoly 3:
mpol x y 
a=[10, 31;
   12, 45; 
   -9, 10;
   [30, -3;
   -7, 53]; %anchor positions
J=0;
for i=1:3
   J=J+((x-a(i,1))^2+(y-a(i,2))^2-d(i)^2)^2;
end
P = msdp(min(J));
[status,obj] = msol(P)
sol3 = double([x y]); 
clear x y
mpol x y 
J=J+((x-a(4,1))^2+(y-a(4,2))^2-d(4)^2)^2;
P = msdp(min(J));
[status,obj] = msol(P)
sol4 = double([x y]); 
clear x y
mpol x y 
J=J+((x-a(5,1))^2+(y-a(5,2))^2-d(5)^2)^2;
P = msdp(min(J));
[status,obj] = msol(P)
sol5 = double([x y]); 