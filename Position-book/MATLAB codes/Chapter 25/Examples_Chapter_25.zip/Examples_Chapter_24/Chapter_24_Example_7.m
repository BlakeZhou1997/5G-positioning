%Using SOSTOOLS:
clear all
A=[0 0 ;
    2 -1;
    3 2 ;
    4 1] ; %The positions of Robot 1
B=[1 7 ; 
    2 5;
    6 8;
    8 4]; %The Positions of Robot 2

theta1=0;

B_2(1,:)=[0 0];
for i=2:5
    B_2(i,:)=(B(i,:)-B(1,:));
end
B_2=B_2/10;

 A=A/10;
 B=B/10;

syms x1 x2 x3 x4 y1 y2 y3 y4
X=[x1 x2 x3 x4 ];
Y=[y1 y2 y3 y4];

A_global=A;
sample=4;
 for i=1:sample
     D_real(i)=norm(A(i,:)-B(i,:));
 end
D=D_real+random('normal',0,.1,1,sample)/10; %distance measurements

B_2(2:sample,:)=B_2(2:sample,:)+random('normal',0,.1,sample-1,2)/10;
 for i=1:sample
    for j=i+1:sample
        d(i,j)=norm(B_2(i,:)-B_2(j,:)); %odometery
        d(j,i)=d(i,j);
    end
end
J=0;
A(2:sample,:)=A(2:sample,:)+random('normal',0,.1,sample-1,2)/10; %odometery
for i=1:sample
   J=J+((X(i)-A(i,1))^2+(Y(i)-A(i,2))^2-D(i)^2)^2;
end
for i=1:sample
    for j=i+1:sample
        J=J+((X(i)-X(j))^2+(Y(i)-Y(j))^2-d(i,j)^2)^2;      
    end
end
tic
[bnd,vars,xopt] = findbound(J)
B_hat=[];
for i=1:sample
    B_hat=[B_hat; xopt(i) xopt(i+sample)];
end

J_phi=0;
P=[];
syms c s
for i=2:sample
    P=[P;B_hat(i,:)'-B_hat(1,:)'-[c s;-s c]*B_2(i,:)'];
end
for i=1:2*(sample-1)
    J_phi=J_phi+P(i)^2;
end
h=c^2+s^2-1;
[gam,vars,trig_phi] = findbound(J_phi,[],h,4)

B_global_hat=[];
for i=1:sample
     B_global_hat(i,:)=([cos(theta1) sin(theta1);-sin(theta1) cos(theta1)]*B_hat(i,:)'+A(1,:)')';
end
phi=acos(trig_phi(1));
