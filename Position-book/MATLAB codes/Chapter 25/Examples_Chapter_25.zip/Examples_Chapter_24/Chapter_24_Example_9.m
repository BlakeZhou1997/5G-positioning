clear all
%Using GloptiPoly 3:
A=[0,0;
    2.3,5;
    4 2;
    9 0]/10;
B=[ 5, 1;
    2, 4;
    5, 7;
    3, 2]/10;
Ap=A(1:4,:);
Bp=B(1:4,:);
sigma=.1;    
for i=1:size(A,1)
  theta(i,:)=(B(i,:)-A(i,:))/norm(B(i,:)-A(i,:))+ random('normal',0,sigma);
end
mpol t1 t2 t3 t4
X=[t1*theta(1,1)+A(1,1);
        t2*theta(2,1)+A(2,1);
        t3*theta(3,1)+A(3,1);
        t4*theta(4,1)+A(4,1);
Y=[t1*theta(1,2)+A(1,2);
        t2*theta(2,2)+A(2,2);
        t3*theta(3,2)+A(3,2);
        t4*theta(4,2)+A(4,2);
G=0;
for i=1:size(Ap,1)       
   for j=i+1:size(Ap,1)             
     G=G+((X(i)-X(j))^2+(Y(i)-Y(j))^2-(norm(B(i,:)-B(j,:))+10*sigma)^2)^2;
   end
end    
P=msdp(min(G)); 
[status,obj]=msol(P);
CP=[];
for i=1:size(Ap,1)
    CP=[CP;X(i) Y(i)];
end
if status==1
    cp=double(CP)*10;
end
