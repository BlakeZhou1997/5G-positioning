clc
clear all
close all

d = [10,10];
P0 = [2,3,4,5];
fc = [.1,.5,1,1.5,2]*1e9;
M = 200;
N = 4096;
Ts = 1e-10;
df = 1/(N*Ts);
InitEps_Water;

Theta = pi/4;
R = sum(d)/cos(Theta);
% P0 = 6;
for p = 1:5
    eps1 = mean(eps(:,:,p)');
%     eps1 = eps1(end:-1:1);
    theta(p,2) = fsolve(@(x) Theta2(x,Theta,d,eps1),pi/4);
%     tan(Theta)*sum(d) - sum(sin(theta(p,4))*d.*sqrt(eps1)./sqrt(eps1(4)-sin(theta(p,4))^2*eps1))
        theta(p,1) = asin(sin(theta(p,2))*sqrt(eps1(1))/sqrt(eps1(2)));
end
Loop = 100;

sigma_tau = (0.5:0.25:5)*1e-9;

for loopParam = 1:length(P0)
    P = P0(loopParam);
    rand('seed',0)
    h = exp(-2i*pi*rand);    % Multipath Channel
    Inds = [M:-1:1,N-1:-1:N-M];   % 2M alocated subcarriers
    S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
    for loopSNR = 1:length(sigma_tau)  
        randn('seed',0);
        
            for p = 1:P
                Eps0 = mean(eps(:,:,p)');
                r = d./cos(theta(p,:));
%                 [r0,k_tau,vars,delay] = TimeFreqDispChannel3(Inds,N,S,eps(:,:,p),Ts,d(2),h);
                tau_hat_hat(p,1) = d*(sqrt(Eps0*Eps0(2))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))'/3e8;
                Gamma(p,:) = (sqrt(Eps0*Eps0(2))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))/3e8;
            end
            for loop = 1:Loop    
                tau_hat = tau_hat_hat + randn(P,1)*sigma_tau(loopSNR);   
                d_hat = Gamma\tau_hat;
                D = sum(d_hat);
                for p = 1:P;
                    Eps0 = mean(eps(:,:,p)');
                    r_hat(p) = D*sqrt(1+(sum(sin(theta(p,2))*(d_hat'.*sqrt(Eps0))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))/D)^2);
                end
                    er(loop) = (abs(R - mean(r_hat))); %mean(mean(theta,2))
            end
        E1(loopSNR,loopParam) = sum(er)/(loop)
        
     end
end 
%%
clear tau_hat_hat Gamma r_hat
d = [50,50];
P0 = [2,3,4,5];
fc = [.1,.5,1,1.5,2]*1e9;
M = 50;
N = 4096;
Ts = 1e-9;
df = 1/(N*Ts);
InitEps_Water;

Theta = pi/4;
R = sum(d)/cos(Theta);
% P0 = 6;
for p = 1:5
    eps1 = mean(eps(:,:,p)');
%     eps1 = eps1(end:-1:1);
    theta(p,2) = fsolve(@(x) Theta2(x,Theta,d,eps1),pi/4);
    tan(Theta)*sum(d) - sum(sin(theta(p,2))*d.*sqrt(eps1)./sqrt(eps1(2)-sin(theta(p,2))^2*eps1))
        theta(p,1) = asin(sin(theta(p,2))*sqrt(eps1(1))/sqrt(eps1(2)));
end

sigma_tau = (0.5:0.25:5)*1e-9;

for loopParam = 1:length(P0)
    P = P0(loopParam);
    rand('seed',0)
    h = exp(-2i*pi*rand);    % Multipath Channel
    Inds = [M:-1:1,N-1:-1:N-M];   % 2M alocated subcarriers
    S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
    for loopSNR = 1:length(sigma_tau)  
        randn('seed',0);
        
            for p = 1:P
                Eps0 = mean(eps(:,:,p)');
                r = d./cos(theta(p,:));
%                 [r0,k_tau,vars,delay] = TimeFreqDispChannel3(Inds,N,S,eps(:,:,p),Ts,d(2),h);
                tau_hat_hat(p,1) = d*(sqrt(Eps0*Eps0(2))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))'/3e8;
                Gamma(p,:) = (sqrt(Eps0*Eps0(2))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))/3e8;
            end
            for loop = 1:Loop    
                tau_hat = tau_hat_hat + randn(P,1)*sigma_tau(loopSNR);   
                d_hat = Gamma\tau_hat;
                D = sum(d_hat);
                for p = 1:P;
                    Eps0 = mean(eps(:,:,p)');
                    r_hat(p) = D*sqrt(1+(sum(sin(theta(p,2))*(d_hat'.*sqrt(Eps0))./sqrt(Eps0(2)-sin(theta(p,2))^2*Eps0))/D)^2);
                end
                    er(loop) = (abs(R - mean(r_hat))); %mean(mean(theta,2))
            end
        E2(loopSNR,loopParam) = sum(er)/(loop)
        
     end
end 
subplot(1,2,1)
semilogy(sigma_tau*1e+9,E1(:,1),'-.ko','LineWidth',1.5)
hold all
semilogy(sigma_tau*1e+9,E2(:,1),'-ko','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E1(:,2),'-.ks','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E2(:,2),'-ks','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E1(:,3),'-.kv','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E2(:,3),'-kv','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E1(:,4),'-.k^','LineWidth',1.5)
semilogy(sigma_tau*1e+9,E2(:,4),'-k^','LineWidth',1.5)

ax = gca;
ax.FontSize = 20;
ax.XLim = [sigma_tau(1)*1e+9 sigma_tau(end)*1e+9];
ax.FontName = 'Times New Roman';
LegendSTR{1} =' |r| = 30m, P = 2 ';
LegendSTR{2} =' |r| = 150m, P = 2';
LegendSTR{3} =' |r| = 30m, P = 3';
LegendSTR{4} =' |r| = 150m, P = 3';
LegendSTR{5} =' |r| = 30m, P = 4';
LegendSTR{6} =' |r| = 150m, P = 4';
LegendSTR{7} =' |r| = 30m, P = 5';
LegendSTR{8} =' |r| = 150m, P = 5';
legend(LegendSTR)
xlabel('Average ToA Error (ns)','FontSize',20)
ylabel('Average Range Estimation Error (m)','FontSize',20)
grid on

%%
