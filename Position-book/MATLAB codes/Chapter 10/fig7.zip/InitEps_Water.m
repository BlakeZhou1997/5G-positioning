for k = 1:5
    f = [fc(k)-M*df,fc(k)+M*df];
    eps0 = 1 + (79 - 1)./(1-1i*1.06e-12*2*pi*f)+1./(1i*2*pi*f*0.795e-11);
    Eps_I = real(eps0);
    Eps_Q = imag(eps0);
    eps(:,:,k)  = [1 1;(Eps_I + sqrt(Eps_I.^2 + Eps_Q.^2))/2];
end



