function f = Theta2(thetaM,theta,d,eps)
M = length(d);
%f = r - sum(d(1:M-1)./tan(asin(sin(thetaM)*sqrt(eps(1:M-1))/sqrt(eps(M))))) - d(M)/tan(thetaM);
%f = r - sum(d*sqrt(eps(M)).*cos(theta-asin(sin(thetaM*sqrt(eps)/sqrt(eps(M)))))...
%./(sqrt(eps)*sin(thetaM))) - d(M)*cos(theta - thetaM)/sin(thetaM);
f = sum(d)*tan(theta) - sum(sin(thetaM)*d.*sqrt(eps)./sqrt(eps(M)-sin(thetaM)^2*eps));