function [s,D0,vars,Delay,Delay_actual] = TimeFreqDispChannel3(Inds,K,S,Eps,Ts,d,h)
M = length(Inds);%[M,K] = size(W);   % M: Number of Allocated Subcarriers, K: length FFT
c = 3e8;
rand('seed',0);
L = length(h);
Ld = size(d,2);
% desiging the length of the received signal
[a,b] = max(Eps(:,1));
eps = Eps(b,2):(Eps(b,1) - Eps(b,2))/(M-1):Eps(b,1);
v = c./(sqrt(eps));
Ls = max(round(sum(d(L,:))./(v*Ts))) + 3*K;
for k = 1:L
    for kk = 1:Ld
        eps = Eps(kk,2):(Eps(kk,1) - Eps(kk,2))/(M-1):Eps(kk,1);
        v = c./(sqrt(eps));
        t = d(k,kk)./v;
%         dt = t - t((N+1)/2);
        delays_actual(kk,:) = (t/Ts);
%         delays(kk,:) = round(t/Ts);
    end
    if kk >1
        delays_actual = sum(delays_actual);
    end
        delays = floor(delays_actual);
        dt = (delays_actual - delays);
    for  kk = 1:M
         W(kk,:) = exp(2i*pi*Inds(kk)*((1:K)-(delays_actual(kk)-delays(1)))/K)/sqrt(K);
%          W(kk,:) = exp(2i*pi*Inds(kk)*((1:K)-dt(kk))/K)/sqrt(K);
    end
    if k == 1
        D0 = mean(delays_actual(M/2:M/2+1));
        Dstart = delays(1);
    end

%     Lst = Dmax  + K;
    St = zeros(M,Ls);
    for kk = 1:M
        St(kk,delays(kk):delays(kk) + K - 1) = W(kk,:)*S(kk);%*exp(-2i*pi*kk*dt(kk)/K);
    end
    y(k,:) = h(k)*sum(St);
    Delay_actual(k,:) = delays_actual;
    Delay(k,:) = delays;
end
if k>1
    s = sum(y);
else 
    s = y;
end
Dmax = delays(end);
vars = var(s(s~=0));



