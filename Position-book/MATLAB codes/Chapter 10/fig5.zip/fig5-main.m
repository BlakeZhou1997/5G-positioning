% clc
clear all
close all
%% ------------------------ Waveform
LOOP = 1 ;
SNRdB0 = -4:2:30;
M0 =  [8,12,25,50];
Ts1 = 1e-9;
N1 = 1024;
A = [1 1;.5 .25];
Ts2 = 2*Ts1;
N2 = N1;
fc = 1e9;
df = 1/(N1*Ts1);
%% 
L = 1;          % flat channel
d0 = [1.5,3,6];1:0.1:5;
D = [0.5,0.8,1.2,1];
for loopParam = 1:4
    clear W1    
    M = M0(loopParam);
    InitEps_Clay;
    %ones(2*M,1);
    Inds = [M:-1:1,N1-1:-1:N1-M];   % 2M alocated subcarriers    
    for  k = 1:2*M
         W1(k,:) = exp(2i*pi*Inds(k)*(1:N1)/N1)/sqrt(N1);
    end
    W01 = conj([W1,W1,W1]);
    for loopSNR = 1:length(SNRdB0)
        randn('seed',0);
        rand('seed',0);
        S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
        h1 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        h2 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        SNRdb = SNRdB0(loopSNR);
        for loopd = 1:length(d0)
            %% -------------- Correlation Based Technique
            randn('seed',0);
            rand('seed',0);
            d = D*d0(loopd);   
            [r1,k_tau1,vars1,delay1,delay_actual1] = TimeFreqDispChannel3(Inds,N1,S,eps1(:,:,loopParam),Ts1,d,h1/abs(h1)^2);
%             MyDelay(:,loopd) = delay_actual1.';
            [r2,k_tau2,vars2,delay2,delay_actual2] = TimeFreqDispChannel3(Inds,N2,S,eps2(:,:,loopParam),Ts2,d,h2/abs(h2)^2);
            sigma1 = sqrt(vars1*(10^(-SNRdb/10))/2);
            sigma2 = sqrt(vars2*(10^(-SNRdb/10))/2);
            ns1 = estimatens(r1,conj(W1));
            if ns1<0
                ns1 = 0;
            end
            ns2 = ns1/2;
           
            Lr1 = length(r1);
            Lr2 = length(r2);
            for loop = 1:LOOP
                r_1 = r1 + sigma1*(randn(1,Lr1) + 1i*randn(1,Lr1));
                r_2 = r2 + sigma2*(randn(1,Lr2) + 1i*randn(1,Lr2));
                R1 = W01*r_1(ns1+1:ns1 + 3*N1).';
                R2 = W01*r_2(ns2+1:ns2 + 3*N1).';
                
                R1 = R1./S;
                x1 = R1(1:M)./R1(2*M:-1:M+1);
                [a,b1] = max(abs(W1(1:M,:)'*conj(x1))); 
                
                R2 = R2./S;
                x2 = R2(1:M)./R2(2*M:-1:M+1);     
                [a,b2] = max(abs(W1(1:M,:)'*conj(x2))); 
                
                X = A\[(b1/2 + ns1 +1);(b2/2 + ns2 +1)];
                if (X(1)- ns1)>= N1
                    X(1) = X(1) - N1/2;
                end
                k_tau_hat = X(1);
                e1(loop) = abs((k_tau1) - k_tau_hat)*Ts1;
                if e1(loop)>N1*Ts1/4 
                    e1(loop) = 0;
                end
            end
%             e1(e1>N1*Ts1/4) = 0;
            e2(loopd) = mean(e1);
        end
        E1(loopSNR,loopParam) = mean(e2)
    end
end

%% 
N1 = 1024;
N2 = N1;
df = 1/(N1*Ts1);

for loopParam = 1:4
    clear W1    
    M = M0(loopParam);
    InitEps_Clay;
    %ones(2*M,1);
    Inds = [M:-1:1,N1-1:-1:N1-M];   % 2M alocated subcarriers    
    for  k = 1:2*M
         W1(k,:) = exp(2i*pi*Inds(k)*(1:N1)/N1)/sqrt(N1);
    end
    W01 = conj([W1,W1,W1]);
    for loopSNR = 1:length(SNRdB0)
        randn('seed',0);
        rand('seed',0);
        S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
        h1 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        h2 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        SNRdb = SNRdB0(loopSNR);
        for loopd = 1:length(d0)
            %% -------------- Correlation Based Technique
            randn('seed',0);
            rand('seed',0);
            d = d0(loopd);   
            [r1,k_tau1,vars1,delay1,delay_actual1] = TimeFreqDispChannel3(Inds,N1,S,eps1(:,:,loopParam),Ts1,d,h1/abs(h1)^2);
            [r2,k_tau2,vars2,delay2,delay_actual2] = TimeFreqDispChannel3(Inds,N2,S,eps2(:,:,loopParam),Ts2,d,h2/abs(h2)^2);
            sigma1 = sqrt(vars1*(10^(-SNRdb/10))/2);
            sigma2 = sqrt(vars2*(10^(-SNRdb/10))/2);
            ns1 = estimatens(r1,conj(W1));
            if ns1<0
                ns1 = 0;
            end
            ns2 = ns1/2;
           
            Lr1 = length(r1);
            Lr2 = length(r2);
            for loop = 1:LOOP
                r_1 = r1 + sigma1*(randn(1,Lr1) + 1i*randn(1,Lr1));
                r_2 = r2 + sigma2*(randn(1,Lr2) + 1i*randn(1,Lr2));
                R1 = W01*r_1(ns1+1:ns1 + 3*N1).';
                R2 = W01*r_2(ns2+1:ns2 + 3*N1).';
                
                R1 = R1./S;
                x1 = R1(1:M)./R1(2*M:-1:M+1);
                [a,b1] = max(abs(W1(1:M,:)'*conj(x1))); 
                
                R2 = R2./S;
                x2 = R2(1:M)./R2(2*M:-1:M+1);     
                [a,b2] = max(abs(W1(1:M,:)'*conj(x2))); 
                
                X = A\[(b1/2 + ns1 +1);(b2/2 + ns2 +1)];
                if (X(1)- ns1)>= N1
                    X(1) = X(1) - N1/2;
                end
                k_tau_hat = X(1);
                e1(loop) = abs((k_tau1) - k_tau_hat)*Ts1;
            end
            e2(loopd) = mean(e1);
        end
        E2(loopSNR,loopParam) = mean(e2)
    end
end

%% 
N1 = 2048;
N2 = N1;
df = 1/(N1*Ts1);

for loopParam = 1:4
    clear W1    
    M = M0(loopParam);
    InitEps_Clay;
    %ones(2*M,1);
    Inds = [M:-1:1,N1-1:-1:N1-M];   % 2M alocated subcarriers    
    for  k = 1:2*M
         W1(k,:) = exp(2i*pi*Inds(k)*(1:N1)/N1)/sqrt(N1);
    end
    W01 = conj([W1,W1,W1]);
    for loopSNR = 1:length(SNRdB0)
        randn('seed',0);
        rand('seed',0);
        S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
        h1 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        h2 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        SNRdb = SNRdB0(loopSNR);
        for loopd = 1:length(d0)
            %% -------------- Correlation Based Technique
            randn('seed',0);
            rand('seed',0);
            d = d0(loopd);   
            [r1,k_tau1,vars1,delay1,delay_actual1] = TimeFreqDispChannel3(Inds,N1,S,eps1(:,:,loopParam),Ts1,d,h1/abs(h1)^2);
            [r2,k_tau2,vars2,delay2,delay_actual2] = TimeFreqDispChannel3(Inds,N2,S,eps2(:,:,loopParam),Ts2,d,h2/abs(h2)^2);
            sigma1 = sqrt(vars1*(10^(-SNRdb/10))/2);
            sigma2 = sqrt(vars2*(10^(-SNRdb/10))/2);
            ns1 = estimatens(r1,conj(W1));
            if ns1<0
                ns1 = 0;
            end
            ns2 = ns1/2;
           
            Lr1 = length(r1);
            Lr2 = length(r2);
            for loop = 1:LOOP
                r_1 = r1 + sigma1*(randn(1,Lr1) + 1i*randn(1,Lr1));
                r_2 = r2 + sigma2*(randn(1,Lr2) + 1i*randn(1,Lr2));
                R1 = W01*r_1(ns1+1:ns1 + 3*N1).';
                R2 = W01*r_2(ns2+1:ns2 + 3*N1).';
                
                R1 = R1./S;
                x1 = R1(1:M)./R1(2*M:-1:M+1);
                [a,b1] = max(abs(W1(1:M,:)'*conj(x1))); 
                
                R2 = R2./S;
                x2 = R2(1:M)./R2(2*M:-1:M+1);     
                [a,b2] = max(abs(W1(1:M,:)'*conj(x2))); 
                
                X = A\[(b1/2 + ns1 +1);(b2/2 + ns2 +1)];
                if (X(1)- ns1)>= N1
                    X(1) = X(1) - N1/2;
                end
                k_tau_hat = X(1);
                e1(loop) = abs((k_tau1) - k_tau_hat)*Ts1;
            end
            e2(loopd) = mean(e1);
        end
        E3(loopSNR,loopParam) = mean(e2)
    end
end

%% 




N1 = 4096;
N2 = N1;
df = 1/(N1*Ts1);

for loopParam = 1:4
    clear W1    
    M = M0(loopParam);
    InitEps_Clay;
    %ones(2*M,1);
    Inds = [M:-1:1,N1-1:-1:N1-M];   % 2M alocated subcarriers    
    for  k = 1:2*M
         W1(k,:) = exp(2i*pi*Inds(k)*(1:N1)/N1)/sqrt(N1);
    end
    W01 = conj([W1,W1,W1]);
    for loopSNR = 1:length(SNRdB0)
        randn('seed',0);
        rand('seed',0);
        S = (2*round(rand(2*M,1))-1) + 1i*(2*round(rand(2*M,1))-1);
        h1 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        h2 = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
        SNRdb = SNRdB0(loopSNR);
        for loopd = 1:length(d0)
            %% -------------- Correlation Based Technique
            randn('seed',0);
            rand('seed',0);
            d = d0(loopd);   
            [r1,k_tau1,vars1,delay1,delay_actual1] = TimeFreqDispChannel3(Inds,N1,S,eps1(:,:,loopParam),Ts1,d,h1/abs(h1)^2);
            [r2,k_tau2,vars2,delay2,delay_actual2] = TimeFreqDispChannel3(Inds,N2,S,eps2(:,:,loopParam),Ts2,d,h2/abs(h2)^2);
            sigma1 = sqrt(vars1*(10^(-SNRdb/10))/2);
            sigma2 = sqrt(vars2*(10^(-SNRdb/10))/2);
            ns1 = estimatens(r1,conj(W1));
            if ns1<0
                ns1 = 0;
            end
            ns2 = ns1/2;
           
            Lr1 = length(r1);
            Lr2 = length(r2);
            for loop = 1:LOOP
                r_1 = r1 + sigma1*(randn(1,Lr1) + 1i*randn(1,Lr1));
                r_2 = r2 + sigma2*(randn(1,Lr2) + 1i*randn(1,Lr2));
                R1 = W01*r_1(ns1+1:ns1 + 3*N1).';
                R2 = W01*r_2(ns2+1:ns2 + 3*N1).';
                
                R1 = R1./S;
                x1 = R1(1:M)./R1(2*M:-1:M+1);
                [a,b1] = max(abs(W1(1:M,:)'*conj(x1))); 
                
                R2 = R2./S;
                x2 = R2(1:M)./R2(2*M:-1:M+1);     
                [a,b2] = max(abs(W1(1:M,:)'*conj(x2))); 
                
                X = A\[(b1/2 + ns1 +1);(b2/2 + ns2 +1)];
                if (X(1)- ns1)>= N1
                    X(1) = X(1) - N1/2;
                end
                k_tau_hat = X(1);
                e1(loop) = abs((k_tau1) - k_tau_hat)*Ts1;
            end
            e2(loopd) = mean(e1);
        end
        E4(loopSNR,loopParam) = mean(e2)
    end
end
figure
semilogy(SNRdB0,E1(:,1),'-ok','LineWidth',1.5,'MarkerSize',10)
hold all
semilogy(SNRdB0,E1(:,2),'-sk','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E1(:,3),'->k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E1(:,4),'-<k','LineWidth',1.5,'MarkerSize',10)
figure
semilogy(SNRdB0,E2(:,1),'-ok','LineWidth',1.5,'MarkerSize',10)
hold all
semilogy(SNRdB0,E2(:,2),'-sk','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E2(:,3),'->k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E2(:,4),'-<k','LineWidth',1.5,'MarkerSize',10)
figure
semilogy(SNRdB0,E3(:,1),'-ok','LineWidth',1.5,'MarkerSize',10)
hold all
semilogy(SNRdB0,E3(:,2),'-sk','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E3(:,3),'->k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E3(:,4),'-<k','LineWidth',1.5,'MarkerSize',10)
figure
semilogy(SNRdB0,E4(:,1),'-ok','LineWidth',1.5,'MarkerSize',10)
hold all
semilogy(SNRdB0,E4(:,2),'-sk','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E4(:,3),'->k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdB0,E4(:,4),'-<k','LineWidth',1.5,'MarkerSize',10)