% This mfile generates the waveform using the InitPhi.m and plots the
% autocorrelation levels of their corresopnding mathced filters
% Created by: Mohsen Jamalabdollahi

%% 
clc
clear all
close all
Nvalues = [128,256,512,1024];
for k = 1:4
    N = Nvalues(k);                         % length of signal
    InitPhi;                                % Phi
    s = exp(1i*Phi);                        % waveform
    C = (abs(conv(s,conj(s(end:-1:1)))));   % Autocorrelation Levels
    figure
    plot(-(N-1):N-1,20*log10(C/max(C)),'LineWidth',1.5) 
    xlabel('Index')
    ylabel('20log_{10}|C|')
    title(['N = ' num2str(N) ''])
end