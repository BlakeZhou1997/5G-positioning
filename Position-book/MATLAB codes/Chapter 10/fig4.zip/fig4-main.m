clc
clear all
close all
N = 512;
InitPhi;

% N = 128;
s = exp(1i*Phi);%WaveformDesign(N,35,8,.6);
L = 1;
LOOP = 1000;
SNRdb = -2:2:30;
OverSampleRate = 1;
Ts = 1e-6;
OverSampleRate0 = [2,4,8,16,32,64,128];
for loopParam = 1:length(OverSampleRate0)
    OverSampleRate = OverSampleRate0(loopParam);
    M = 2*N*OverSampleRate;                 % Received Signal Length
    if OverSampleRate>1

        f = rcosine(1,OverSampleRate);
    else
        f = 1;
    end
%     % f = rcosdesign(0.25,8,8);
    Lf = length(f);
    sz = zeros(1,N*OverSampleRate);
    sz(1:OverSampleRate:end) = s;
    sf = conv(sz,f);
    sf = sf((Lf-1)/2+1:N*OverSampleRate+(Lf-1)/2);
    TsOver  = Ts/OverSampleRate;
    Res = 3e8*TsOver;
    for loopSNR = 1:length(SNRdb)
        SNR = SNRdb(loopSNR);
        e = 0;
        randn('seed',0)
        rand('seed',0)
        
        for loop = 1:LOOP
            c = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend').*exp(-(0:63)/32);
            R = rand*2000 + Res;
            tau = R/3e8;
            k_tau = 23;floor(tau/TsOver);
            e0 = rem(tau,TsOver);
            sigma2_s = var(conv(s,c));
            sigma = sqrt(sigma2_s*10^(-SNR/10)/2);
            r = zeros(L,M);
            for k = 1:128/OverSampleRate:64
%             for k = 1:L
                r(k,k_tau + (k-1)*OverSampleRate:(k_tau+ (N+k-1)*OverSampleRate-1)) = c(k)*sf;
            end

            r = sum(r);
            r = r + sigma*(randn(1,M) + 1i*randn(1,M));
    %         r = conv(r,f);
    % length(f);
%              r = r((Lf-1)/2+1:end-(Lf-1)/2);
            for k = 1:OverSampleRate
                y(k,:) = r(k:OverSampleRate:end);
                C(k,:) = abs(conv(y(k,:),conj(s(end:-1:1)))).^2;
%                 subplot(OverSampleRate,1,k)
%                 plot([-100:100],10*log10(C(k,28+5:228+5)/max(C(k,:))),'k-o','LineWidth',1.5,'MarkerSize',4)
%                 xlabel('(a)','FontSize',18)
%                 ylabel('c^{(1)} (dB)','FontSize',18)
%                 grid on
            end
            [temp,K_tau] = max(C.');
            for k = 1:OverSampleRate
                Co(k) = C(k,K_tau(k))/C(k,K_tau(k)-1);
            end
            [temp,k_tau_f] = max(Co);
            k_tau_hat = (K_tau(k_tau_f)-N)*OverSampleRate + k_tau_f;  
            e = e + (abs(k_tau - k_tau_hat)*TsOver + e0)^2;
        end
        E(loopSNR,loopParam) = e/loop
        if E(loopSNR,loopParam)==0
            break
        end
    end
end

OverSampleRate = 4;
TsOver  = Ts/OverSampleRate;
M = 512*OverSampleRate;
Ls = length(s_SCAN);
Res = 3e8*TsOver;
for loopSNR = 1:length(SNRdb)
    SNR = SNRdb(loopSNR);
    e_SCAN = 0;
    randn('seed',10)
    rand('seed',10)
%     c = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
    for loop = 1:LOOP
     c = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend').*exp(-(0:63)/32);   
     c = [c(1),c(33)];
        R = rand*2000 + Res;
            tau = R/3e8;
            k_tau = floor(tau/TsOver);
            e0 = rem(tau,TsOver);
        S_SCAN = conv(c,s_SCAN);
            
        sigma2_s = var(S_SCAN);
        sigma = sqrt(sigma2_s*10^(-SNR/10)/2);
        r_S = zeros(1,M);
        r_S(1,k_tau:k_tau + Ls + 2 - 2) = S_SCAN.';
        r_S = r_S + sigma*(randn(1,M) + 1i*randn(1,M));
        CS = abs(conv(r_S,conj(s_SCAN(end:-1:1))));
        [temp,k_tau_hat_SCAN] = max(CS);
        e_SCAN = e_SCAN + (abs(k_tau - k_tau_hat_SCAN + Ls  - 1)*TsOver + e0)^2;
    end
    E_SCAN(loopSNR) = sum(e_SCAN)/loop
end
% % semilogy(SNRdb,E(:,1),'-sk','LineWidth',2)
% % hold all
% % semilogy(SNRdb,E_SCAN,'-ok','LineWidth',2)
% % semilogy(SNRdb,E(:,2:end),'-sk','LineWidth',2)
 %% 
% N = 128;
% InitPhi;
% s = exp(1i*Phi);
% K = N*OverSampleRate;
% Ls = N*OverSampleRate;
% for k = 1:K
%     W(k,:) = exp(-2i*pi*(1:Ls)*(k-1)/K)/sqrt(K);
% end
% k_tau = 1;
% df = 1/(K*Ts);
% % randn('seed',0)
% % rand('seed',0)
% c = sort(sqrt(randn(1,L).^2 + randn(1,L).^2).*exp(2i*pi*rand(1,L)),'descend');
% % c = c(1:128/OverSampleRate:end);
% % L = length(c);
% sigma2_s = var(conv(sf,c));
% s1 = zeros(1,Ls);
%     s1(k_tau:k_tau + N*OverSampleRate-1) = sf.';
%     for k = 1:Ls-L+1
%         S(k+L-1,:) = s1(k+L-1:-1:k);
%     end
%     for ktau = 0:L-1
%         SW = W*S(:,ktau+1);
%         for n = 1:Ls
%             Wtau(n,:) = exp(2i*pi*(0:K-1)*(n-ktau)/K)/sqrt(K);
%         end
%         ds(:,ktau+1) = Wtau*(-2i*pi*df*(0:K-1)'.*SW);
%     end
% 
% for loopSNR = 1:length(SNRdb)
%     SNR = SNRdb(loopSNR);
%     sigma = sqrt(sigma2_s*10^(-SNR/10)/2);
%     J = 2*real(diag(c')*ds'*ds*diag(c))/(sigma^2);
% 
%     J(1:L,L+1:2:3*L) = 2*real(diag(c')*ds'*S)/sigma^2;
%     J(1:L,L+2:2:3*L) = -2*real(diag(c')*ds'*S)/sigma^2;
%     J(L+1:2:3*L,1:L) = (2*real(diag(c')*ds'*S)/sigma^2).';
%     J(L+2:2:3*L,1:L) = (-2*real(diag(c')*ds'*S)/sigma^2).';
% 
%     J(L+1:2:3*L,L+1:2:3*L) = 2*real(ds'*S)/sigma^2;
%     J(L+2:2:3*L,L+2:2:3*L) = (2*real(ds'*S)/sigma^2);
%     J(L+1:2:3*L,L+2:2:3*L) = -2*imag(ds'*S)/sigma^2;
%     J(L+2:2:3*L,L+1:2:3*L) = (-2*imag(ds'*S)/sigma^2);
% 
%     C = inv(J);
%     CRB(loopSNR) = C(1,1)
% end
% %%
SNRdb = SNRdb(1:size(E,1));
% % semilogy(SNRdb,E_SCAN,'->k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,1),'-sk','LineWidth',1.5,'MarkerSize',10)
hold all
semilogy(SNRdb,E(:,2),'-ok','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E_SCAN,'->k','LineWidth',1.5,'MarkerSize',10)
% % semilogy(SNRdb,E(:,2),'-ok','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,3),'-<k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,4),'-^k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,5),'-vk','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,6),'-*k','LineWidth',1.5,'MarkerSize',10)
semilogy(SNRdb,E(:,7),'-dk','LineWidth',1.5,'MarkerSize',10)
% % semilogy(SNRdb,E(:,8),'--k','LineWidth',1.5,'MarkerSize',10)
% % semilogy(SNRdb,2*CRB,'-k','LineWidth',1.5,'MarkerSize',10)
ax = gca;
ax.FontSize = 20;
ax.XLim = [SNRdb(1) SNRdb(end)];
ax.FontName = 'Times New Roman';
% LegendSTR{1} =' M = 1';
LegendSTR{1} =' M = 2';
LegendSTR{3} =' SCAN';
LegendSTR{2} =' M = 4';
LegendSTR{3} =' M = 8';
LegendSTR{4} =' M = 16';
LegendSTR{5} =' M = 32';
LegendSTR{6} =' M = 64';
LegendSTR{7} =' M = 128';
% LegendSTR{10} =' CRLB';
% LegendSTR{5} ='Proposed, M = 75';
% LegendSTR{6} ='Proposed, M = 100';
legend(LegendSTR)
columnlegend(2,LegendSTR)

xlabel('SNR(dB)','FontSize',20)
ylabel('MSE ToA','FontSize',20)
grid on
        
        
%     
